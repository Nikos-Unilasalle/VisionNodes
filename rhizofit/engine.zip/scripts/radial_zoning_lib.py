"""Measured tissue boundaries of a root cross-section, from radial density profiles.

The section is unwrapped in the metaxylem-anchored elliptical frame (rho, phi): rho = 1
on the outer envelope of the metaxylem ring. The unwrap extends to the farthest point of the
section contour (plus a margin), so its extent is set by each section, not by a constant;
the profiles carry their own rho samples (prof['rho'], prof['rho_step']). Along every iso-rho
line, without any cell segmentation, two profiles are measured per angular sector:

  darkness   mean wall darkness
  L_theta    circumferential mean linear intercept = arc length / wall crossings
             (stereological cell-size estimator); L_rho is the same along rays.

Boundaries
  pith        inner edge of the metaxylem ring (median over vessels of their minimum rho)
  metaxylem   rho = 1 by construction
  endodermis  outer edge: change point of [log L_theta, darkness] beyond the ring;
              inner edge: outer edge minus one radial cell (L_rho measured just inside)
  cortex      inner/outer transition: second change point
  rhizodermis one radial cell (measured at the section edge) along the section contour

Change points: optimal piecewise-constant split (dynamic programming) of the sector-median
profiles over rho in [1, edge]; 95 % intervals by bootstrap over angular sectors.
"""
import warnings

import cv2
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks

RHO_STEP = 0.01          # radial sampling of the polar unwrap (rho units), unless the grid would exceed MAX_POLAR_ROWS
EXTENT_MARGIN = 0.15     # rho: the unwrap runs to the farthest point of the section plus this margin
MAX_POLAR_ROWS = 512     # bound of the polar grid (rows x N_PHI) for in-browser use; it exceeds the working root
                         # radius in px (root_web_runner normalises the diameter to 766 px), so a coarser step
                         # (very thick cortex around a small vessel ring) still samples every ray below 1 px
FEATURE_SMOOTH = 0.02    # rho, Gaussian smoothing of the change-point features
N_PHI = 8192
N_SECTORS = 16
N_BOOT = 200
MIN_SEG = 0.12           # minimal zone width (rho units) for the change-point search
SEARCH_FROM = 1.0        # change points are searched outside the metaxylem ring
EDGE_COVER = 0.5         # rho of the section edge = last rho where >= 50 % of rays are inside
WALL_PROMINENCE = {'drawing': 25.0, 'photo': 6.0}  # grey levels of a wall dip
MIN_VESSEL_AREA = 400    # px, same as the publication node
VESSEL_SCORE_MIN = 0.35  # (size / ring median) x (circularity / ring median) below this: not a vessel
DRAWING_MEDIAN_GREY = 225  # median grey inside the section above which the image is a line drawing


def anchor_ellipse(mx_mask):
    """Same fit as geom_ellipse_propagation: fitEllipse on the hull of the metaxylem masks."""
    cnts, _ = cv2.findContours((np.asarray(mx_mask) > 0).astype(np.uint8), cv2.RETR_EXTERNAL,
                               cv2.CHAIN_APPROX_NONE)
    if not cnts:
        raise ValueError('no metaxylem anchor')
    (cx, cy), (w, h), ang = cv2.fitEllipse(cv2.convexHull(np.vstack(cnts)))
    return cx, cy, max(w, 10) / 2, max(h, 10) / 2, np.deg2rad(ang)


def _rho_at(xx, yy, ell):
    cx, cy, a, b, t = ell
    dx, dy = xx - cx, yy - cy
    xr, yr = np.cos(t) * dx + np.sin(t) * dy, -np.sin(t) * dx + np.cos(t) * dy
    return np.sqrt((xr / a) ** 2 + (yr / b) ** 2)


def rho_field(shape, ell):
    yy, xx = np.indices(shape, dtype=np.float32)
    return _rho_at(xx, yy, ell)


def section_extent(section, ell):
    """Farthest rho reached by the section, i.e. max over phi of the section edge rho_edge(phi).

    The section contour is the second geometric invariant next to the metaxylem anchor: the
    extent of the unwrap is read from it, so no root is truncated however thick its cortex.
    """
    cnts, _ = cv2.findContours(np.asarray(section, np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not cnts:
        raise ValueError('empty section mask')
    pts = np.vstack(cnts).reshape(-1, 2).astype(np.float32)
    return float(_rho_at(pts[:, 0], pts[:, 1], ell).max())


def polar_rho(section, ell):
    """Radial samples of the unwrap, from 0 to the section extent plus EXTENT_MARGIN.

    The step is RHO_STEP; past MAX_POLAR_ROWS samples it grows so the grid stays bounded.
    """
    extent = section_extent(section, ell) + EXTENT_MARGIN
    if extent / RHO_STEP <= MAX_POLAR_ROWS:
        return np.arange(0, extent, RHO_STEP)
    return np.linspace(0, extent, MAX_POLAR_ROWS, endpoint=False)


def _unwrap_maps(ell, rho_samples):
    cx, cy, a, b, t = ell
    step = float(rho_samples[1])
    rho = rho_samples[:, None]
    phi = np.linspace(0, 2 * np.pi, N_PHI, endpoint=False)[None, :]
    xr, yr = rho * a * np.cos(phi), rho * b * np.sin(phi)
    mx = (cx + np.cos(t) * xr - np.sin(t) * yr).astype(np.float32)
    my = (cy + np.sin(t) * xr + np.cos(t) * yr).astype(np.float32)
    dphi = 2 * np.pi / N_PHI
    ds_phi = rho * np.sqrt((a * np.sin(phi)) ** 2 + (b * np.cos(phi)) ** 2) * dphi
    ds_rho = np.broadcast_to(step * np.sqrt((a * np.cos(phi)) ** 2 + (b * np.sin(phi)) ** 2), ds_phi.shape)
    return mx, my, ds_phi, ds_rho


def _remap(img, mx, my, nearest=False):
    return cv2.remap(img, mx, my, cv2.INTER_NEAREST if nearest else cv2.INTER_LINEAR,
                     borderMode=cv2.BORDER_CONSTANT, borderValue=0)


def _dips(line, prominence):
    pk, _ = find_peaks(255 - gaussian_filter1d(line.astype(np.float32), 1.0), prominence=prominence)
    out = np.zeros(line.shape, bool)
    out[pk] = True
    return out


def _label_changes(line):
    inside = line > 0
    change = np.r_[False, line[1:] != line[:-1]]
    return change & inside & np.r_[False, inside[:-1]] | (np.r_[False, inside[1:] & ~inside[:-1]])


def _sector_of_phi():
    return np.arange(N_PHI) * N_SECTORS // N_PHI


def _per_sector(values_fn):
    """Stack values_fn(sector columns) for every sector; empty sectors give NaN silently."""
    sec = _sector_of_phi()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        return np.stack([values_fn(sec == s) for s in range(N_SECTORS)], 1)


def _intercepts(cross, inside, ds):
    def one(cols):
        length = (ds[:, cols] * inside[:, cols]).sum(1)
        n = (cross[:, cols] & inside[:, cols]).sum(1)
        with np.errstate(all='ignore'):
            return np.where((n >= 2) & (length > 0), length / np.maximum(n, 1), np.nan)
    return _per_sector(one)


def polar_profiles(gray, section, ell, prominence=None, labels=None):
    """Per-sector radial profiles (rho x sector) of L_theta, L_rho and wall darkness.

    With `labels` (a ground-truth label map) wall crossings are label changes, not dips.
    """
    rho = polar_rho(section, ell)
    step = float(rho[1])
    mx, my, ds_phi, ds_rho = _unwrap_maps(ell, rho)
    inside = _remap(section.astype(np.uint8), mx, my, nearest=True) > 0
    if labels is not None:
        pol = _remap(labels.astype(np.float32), mx, my, nearest=True).astype(np.int32)
        cross_t = np.array([_label_changes(r) for r in pol])
        cross_r = np.array([_label_changes(c) for c in pol.T]).T
        dark = None
    else:
        pol = _remap(gray, mx, my)
        cross_t = np.array([_dips(r, prominence) for r in pol])
        cross_r = np.array([_dips(c, prominence) for c in pol.T]).T
        d = np.where(inside, 255.0 - pol, np.nan)
        with np.errstate(all='ignore'):
            dark = _per_sector(lambda cols: np.nanmean(d[:, cols], 1))
    cover = inside.mean(1)
    edge_idx = int(np.nonzero(cover >= EDGE_COVER)[0].max())
    return {'Lt': _intercepts(cross_t, inside, ds_phi), 'Lr': _intercepts(cross_r, inside, ds_rho),
            'dark': dark, 'cover': cover, 'edge_rho': edge_idx * step, 'polar': pol,
            'cross_r': cross_r, 'inside': inside, 'ds_rho': ds_rho, 'rho': rho, 'rho_step': step,
            'px_per_rho': float(np.median(ds_rho[0]) / step)}


def _segment(f, k, min_len):
    """Optimal split of an (n, d) profile into k constant segments; returns the k-1 cut indices."""
    n = len(f)
    cs = np.vstack([np.zeros((1, f.shape[1])), np.cumsum(f, 0)])
    cs2 = np.r_[0.0, np.cumsum((f ** 2).sum(1))]
    D = np.full((k + 1, n + 1), np.inf)
    B = np.zeros((k + 1, n + 1), int)
    D[0, 0] = 0
    i_all = np.arange(n + 1)
    for s in range(1, k + 1):
        for j in range(s * min_len, n + 1):
            i = i_all[(s - 1) * min_len: j - min_len + 1]
            m = (j - i).astype(float)
            cost = (cs2[j] - cs2[i]) - ((cs[j] - cs[i]) ** 2).sum(1) / m
            tot = D[s - 1, i] + cost
            q = int(np.argmin(tot))
            D[s, j], B[s, j] = tot[q], i[q]
    cuts, j = [], n
    for s in range(k, 0, -1):
        j = B[s, j]
        cuts.append(j)
    return sorted(cuts)[1:]


def _features(prof, rows, px_per_rho):
    """Standardised, smoothed [log L_theta, darkness] sector-median profile along rho."""
    with np.errstate(all='ignore'), warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        lt = np.log(np.nanmedian(prof['Lt'][:, rows], 1) / px_per_rho)
        dk = np.nanmedian(prof['dark'][:, rows], 1)
    f = np.column_stack([lt, dk])
    f = np.nan_to_num((f - np.nanmean(f, 0)) / np.nanstd(f, 0))
    return gaussian_filter1d(f, FEATURE_SMOOTH / prof['rho_step'], axis=0)


def change_points(prof, rng, n_boot=N_BOOT):
    """Endodermis outer edge and cortex transition (rho), with bootstrap 95 % intervals over sectors."""
    rho = prof['rho']
    sel = (rho >= SEARCH_FROM) & (rho <= prof['edge_rho'] - 0.05)
    rr = rho[sel]
    min_len = int(round(MIN_SEG / prof['rho_step']))

    def run(rows):
        return [float(rr[c]) for c in _segment(_features(prof, rows, prof['px_per_rho'])[sel], 3, min_len)]
    base = run(np.arange(N_SECTORS))
    if n_boot:
        boots = np.array([run(rng.integers(0, N_SECTORS, N_SECTORS)) for _ in range(n_boot)])
        ci = np.percentile(boots, [2.5, 97.5], 0).T
    else:
        ci = np.array([[np.nan, np.nan], [np.nan, np.nan]])
    return {'endo_outer': base[0], 'cortex_transition': base[1],
            'endo_outer_ci': ci[0].tolist(), 'cortex_transition_ci': ci[1].tolist()}


def radial_cell_size(prof, lo, hi):
    """Median radial intercept (px) over rho in [lo, hi], all sectors."""
    rho = prof['rho']
    band = prof['Lr'][(rho >= lo) & (rho <= hi)]
    if not np.isfinite(band).any():
        raise ValueError(f'no radial cell size measured between rho {lo:.2f} and {hi:.2f}')
    return float(np.nanmedian(band))


def outermost_layer_px(prof, max_px=120):
    """Radial size of the outermost cell layer: gap between the first two walls met inward from the edge.

    The first wall is the outer (epidermal) wall itself, the second the layer's inner wall.
    """
    inside, cross, ds = prof['inside'], prof['cross_r'], prof['ds_rho']
    out = []
    for j in range(inside.shape[1]):
        idx = np.nonzero(inside[:, j])[0]
        if not len(idx):
            continue
        d, walls = 0.0, []
        for k in range(idx.max(), -1, -1):
            d += ds[k, j]
            if d >= max_px or len(walls) == 2:
                break
            if cross[k, j]:
                walls.append(d)
        if len(walls) == 2:
            out.append(walls[1] - walls[0])
    return float(np.median(out)) if out else float('nan')


def _circularity(component):
    cnts, _ = cv2.findContours(component.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    perimeter = cv2.arcLength(cnts[0], True)
    return 4 * np.pi * component.sum() / max(perimeter ** 2, 1e-9)


def clean_vessels(mx_mask):
    """Metaxylem mask without the candidates that are both small and irregular for their ring.

    The large metaxylem vessels of a polyarch ring have comparable sizes and are round. Each
    candidate is scored by (area / median area) x (circularity / median circularity) of the
    ring: a true vessel may be smaller than the others, or less round when its mask leaks into
    neighbouring cells, but not both. Candidates scoring under VESSEL_SCORE_MIN are dropped.
    """
    mask = np.asarray(mx_mask) > 0
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8))
    ids = [i for i in range(1, n) if stats[i, cv2.CC_STAT_AREA] >= MIN_VESSEL_AREA]
    if len(ids) < 2:
        return mask
    area = np.array([stats[i, cv2.CC_STAT_AREA] for i in ids], float)
    circ = np.array([_circularity(lab == i) for i in ids])
    score = (area / np.median(area)) * (circ / np.median(circ))
    keep = np.zeros(n, bool)
    keep[[i for i, sc in zip(ids, score) if sc >= VESSEL_SCORE_MIN]] = True
    return keep[lab]


def vessel_inner_edges(mx_mask, rho):
    """Minimum rho of every metaxylem vessel (the inner edge of the ring)."""
    n, lab, stats, _ = cv2.connectedComponentsWithStats((np.asarray(mx_mask) > 0).astype(np.uint8))
    edges = [float(rho[lab == i].min()) for i in range(1, n) if stats[i, cv2.CC_STAT_AREA] >= MIN_VESSEL_AREA]
    if not edges:
        raise ValueError(f'no metaxylem vessel reaches {MIN_VESSEL_AREA} px')
    return edges


def guess_kind(gray, section):
    """'drawing' for a line drawing (mostly white inside the section), else 'photo'."""
    return 'drawing' if float(np.median(gray[section])) >= DRAWING_MEDIAN_GREY else 'photo'


def measure_boundaries(gray, section, mx_mask, kind=None, rng=None, n_boot=N_BOOT):
    """All boundaries of one section, in rho units, with their uncertainty and the zone masks."""
    section = np.asarray(section) > 0
    kind = kind or guess_kind(gray, section)
    rng = rng if rng is not None else np.random.default_rng(0)
    mx_mask = clean_vessels(mx_mask)
    ell = anchor_ellipse(mx_mask)
    rho = rho_field(section.shape, ell)
    prof = polar_profiles(gray, section, ell, WALL_PROMINENCE[kind])
    cp = change_points(prof, rng, n_boot)
    vessels = vessel_inner_edges(mx_mask, rho)
    endo_cell_rho = radial_cell_size(prof, cp['endo_outer'] - 0.10, cp['endo_outer']) / prof['px_per_rho']
    rhizo_px = outermost_layer_px(prof)
    b = {'pith': float(np.median(vessels)), 'pith_range': [min(vessels), max(vessels)], 'n_vessels': len(vessels),
         'metaxylem': 1.0, 'endo_inner': cp['endo_outer'] - endo_cell_rho, **cp,
         'endo_cell_rho': endo_cell_rho, 'edge': prof['edge_rho'], 'rhizo_layer_px': rhizo_px,
         'px_per_rho': prof['px_per_rho']}
    return b, zone_masks(rho, section, b), ell, prof


def zone_masks(rho, section, b):
    """Zone masks from measured boundaries; the rhizodermis follows the section contour."""
    sec = section.astype(bool)
    dist = cv2.distanceTransform(sec.astype(np.uint8), cv2.DIST_L2, 5)
    rhizo = sec & (dist <= b['rhizo_layer_px'])
    body = sec & ~rhizo
    return {
        'pith_mask': body & (rho <= b['pith']),
        'vascular_mask': body & (rho > b['pith']) & (rho <= b['endo_inner']),
        'endodermis_mask': body & (rho > b['endo_inner']) & (rho <= b['endo_outer']),
        'inner_cortex_mask': body & (rho > b['endo_outer']) & (rho <= b['cortex_transition']),
        'outer_cortex_mask': body & (rho > b['cortex_transition']),
        'rhizodermis_mask': rhizo,
    }


def major_axis_tilt_deg(ell):
    """Direction of the anchor ellipse's major axis, in degrees [0, 180)."""
    _, _, a, b, t = ell
    return float((np.degrees(t) + (0.0 if a >= b else 90.0)) % 180.0)


def anchor_report(ell):
    """Anchor ellipse in the keys of the Ellipse Propagation report (centre, semi-axes, tilt)."""
    cx, cy, a, b, t = ell
    return {'center_x': float(cx), 'center_y': float(cy), 'major_axis': float(max(a, b)),
            'minor_axis': float(min(a, b)), 'tilt_angle_deg': major_axis_tilt_deg(ell),
            'aspect_ratio': float(max(a, b) / max(min(a, b), 1e-6))}


def ellipse_report(base_report, b):
    """Ellipse report with the measured boundaries in place of the prior scales."""
    return {**base_report, 'scale_pith': b['pith'], 'scale_lpsc': b['endo_inner'],
            'scale_endodermis': b['endo_outer'], 'scale_inner_cortex': b['cortex_transition'],
            'scale_outer_cortex': b['edge'] - b['rhizo_layer_px'] / b['px_per_rho'],
            'scale_rhizodermis': b['edge']}
