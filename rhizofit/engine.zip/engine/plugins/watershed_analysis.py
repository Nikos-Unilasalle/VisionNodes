import cv2
import numpy as np
from registry import NodeProcessor, vision_node

THRESHOLD_MODES = ["Binary", "Binary Inv", "Otsu", "Otsu Inv", "70% of Max", "Triangle", "Triangle Inv"]
AUTO_MODES = (2, 3, 4, 5, 6)
INVERTED_MODES = (1, 3, 6)
TRIANGLE_MODES = (5, 6)


def _threshold_value(mode, manual, region):
    """Threshold for `mode`, computed from `region` pixels (1-D uint8) for auto modes."""
    if mode in (0, 1):
        return float(manual)
    if region.size == 0:
        return 0.0
    if mode == 4:
        return 0.7 * float(region.max())
    method = cv2.THRESH_TRIANGLE if mode in TRIANGLE_MODES else cv2.THRESH_OTSU
    t, _ = cv2.threshold(region.reshape(-1, 1), 0, 255, cv2.THRESH_BINARY + method)
    return float(t)


@vision_node(
    type_id="feat_threshold_adv",
    label="Threshold (Advanced)",
    category='segmentation',
    icon="Layers",
    description="Advanced thresholding: Otsu, Triangle (one dominant background peak + a tail, "
                "e.g. objects on a flat backdrop, even faint/out-of-focus ones) and % of max. "
                "Optional mask: Otsu / % of Max are computed from masked pixels only and the "
                "result is clipped to the mask. Offset shifts the automatic threshold.",
    inputs=[{"id": "image", "color": "image"}, {"id": "mask", "color": "mask", "label": "Region (opt.)"}],
    outputs=[{"id": "main", "color": "image"}, {"id": "mask", "color": "mask"},
             {"id": "value", "color": "scalar", "label": "Threshold"}],
    params=[
        {"id": "mode", "label": "Mode", "type": "enum", "options": THRESHOLD_MODES, "default": 0},
        {"id": "threshold", "label": "Value", "type": "scalar", "min": 0, "max": 255, "default": 127},
        {"id": "offset", "label": "Auto Offset", "type": "scalar", "min": -128, "max": 128, "default": 0},
    ]
)
class AdvancedThresholdNode(NodeProcessor):
    def process(self, inputs, params):
        img = inputs.get('image')
        if img is None: return {"main": None, "mask": None, "value": None}

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if (len(img.shape) == 3 and img.shape[2] >= 3) else img
        mode = int(params.get('mode', 0))

        # Otsu's method requires 8-bit images. Convert float to uint8.
        if mode in AUTO_MODES and gray.dtype != np.uint8:
            gray = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

        region_mask = inputs.get('mask')
        if region_mask is not None:
            if region_mask.ndim == 3:
                region_mask = cv2.cvtColor(region_mask, cv2.COLOR_BGR2GRAY)
            if region_mask.shape[:2] != gray.shape[:2]:
                region_mask = cv2.resize(region_mask, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_NEAREST)
            inside = region_mask > 0
        else:
            inside = None

        region = gray[inside] if inside is not None else gray.ravel()
        t = _threshold_value(mode, params.get('threshold', 127), region)
        if mode in AUTO_MODES:
            t += float(params.get('offset', 0))

        hit = gray <= t if mode in INVERTED_MODES else gray > t
        if inside is not None:
            hit &= inside
        res = hit.astype(np.uint8) * 255
        return {"main": res, "mask": res, "value": t}

@vision_node(
    type_id="feat_morphology_adv",
    label="Morphology (Advanced)",
    category='segmentation',
    icon="Wind",
    description="Advanced morphological operations like Opening, Closing, and Gradient.",
    inputs=[{"id": "mask", "color": "any"}],
    outputs=[{"id": "main", "color": "image"}, {"id": "mask", "color": "mask"}],
    params=[
        {"id": "operation", "label": "Operation", "type": "enum", "options": ["Opening", "Closing", "Gradient", "Top Hat", "Black Hat", "Dilate", "Erode"], "default": 0},
        {"id": "shape", "label": "Kernel Shape", "type": "enum", "options": ["Rect", "Cross", "Ellipse"], "default": 0},
        {"id": "size", "label": "Kernel Size", "type": "scalar", "min": 1, "max": 31, "step": 2, "default": 5},
        {"id": "iterations", "label": "Iterations", "type": "scalar", "min": 1, "max": 10, "default": 1}
    ]
)
class AdvancedMorphologyNode(NodeProcessor):
    def process(self, inputs, params):
        mask = inputs.get('mask') if inputs.get('mask') is not None else (inputs.get('image') if inputs.get('image') is not None else inputs.get('main'))
        if mask is None: return {"main": None, "mask": None}
        
        # Ensure grayscale uint8
        if len(mask.shape) == 3 and mask.shape[2] >= 3:
            mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        mask = mask.astype(np.uint8)
            
        op_idx = int(params.get('operation', 0))
        ops = [cv2.MORPH_OPEN, cv2.MORPH_CLOSE, cv2.MORPH_GRADIENT, cv2.MORPH_TOPHAT, cv2.MORPH_BLACKHAT, cv2.MORPH_DILATE, cv2.MORPH_ERODE]
        op = ops[min(op_idx, len(ops)-1)]
        
        sh_idx = int(params.get('shape', 0))
        shapes = [cv2.MORPH_RECT, cv2.MORPH_CROSS, cv2.MORPH_ELLIPSE]
        shape = shapes[min(sh_idx, len(shapes)-1)]
        
        size = int(params.get('size', 5))
        if size < 1: size = 1
        kernel = cv2.getStructuringElement(shape, (size, size))
        
        iters = int(params.get('iterations', 1))
        
        res = cv2.morphologyEx(mask, op, kernel, iterations=iters)
        return {"main": res, "mask": res}

@vision_node(
    type_id="feat_distance_transform",
    label="Distance Transform",
    category='segmentation',
    icon="Maximize",
    description="Calculates the distance from each pixel to the nearest zero pixel (mask border).",
    inputs=[{"id": "mask", "color": "any"}],
    outputs=[{"id": "main", "color": "image"}, {"id": "dist_map", "color": "any"}],
    params=[
        {"id": "dist_type", "label": "Dist Type", "type": "enum", "options": ["L2 (Euclidean)", "L1 (Manhattan)", "C (Chessboard)"], "default": 0},
        {"id": "mask_size", "label": "Mask Size", "type": "enum", "options": ["3", "5", "Precise"], "default": 1}
    ]
)
class DistanceTransformNode(NodeProcessor):
    def process(self, inputs, params):
        mask = inputs.get('mask')
        if mask is None: return {"main": None, "dist_map": None}
        
        if len(mask.shape) == 3 and mask.shape[2] >= 3:
            mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        mask = mask.astype(np.uint8)
            
        dist_types = [cv2.DIST_L2, cv2.DIST_L1, cv2.DIST_C]
        mask_sizes = [3, 5, 0] # 0 for DIST_MASK_PRECISE
        
        dt = dist_types[int(params.get('dist_type', 0))]
        ms = mask_sizes[int(params.get('mask_size', 1))]
        
        # Watershed logic usually uses L2 with 5x5 or Precise
        dist_map = cv2.distanceTransform(mask, dt, ms)
        
        # For visualization, normalize to 0-255
        vis = cv2.normalize(dist_map, None, 0, 255, cv2.NORM_MINMAX)
        return {"main": vis.astype(np.uint8), "dist_map": dist_map}

@vision_node(
    type_id="feat_connected_components",
    label="Connected Components (Markers)",
    category='segmentation',
    icon="Database",
    description="Labels a binary mask into a marker map to seed Watershed. No "
                "parameters: it labels whatever the mask already contains. For "
                "counting and measuring objects — with a threshold, area filters "
                "and per-object areas and centroids — use 'Connected Components' "
                "instead.",
    inputs=[{"id": "mask", "color": "any"}],
    outputs=[{"id": "main", "color": "image"}, {"id": "markers", "color": "markers"}, {"id": "count", "color": "scalar"}],
    params=[]
)
class ConnectedComponentsNode(NodeProcessor):
    def process(self, inputs, params):
        mask = inputs.get('mask')
        if mask is None: return {"main": None, "markers": None, "count": 0}
        
        if len(mask.shape) == 3 and mask.shape[2] >= 3:
            mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        mask = mask.astype(np.uint8)
            
        # connectedComponents returns num_labels and marker image (int32)
        count, markers = cv2.connectedComponents(mask)
        
        # Visualize markers (labels * step to see colors)
        vis = (markers.astype(np.float32) * (255 / max(1, count))).astype(np.uint8)
        color_vis = cv2.applyColorMap(vis, cv2.COLORMAP_JET)
        color_vis[markers == 0] = 0 # background stay black
        
        return {"main": color_vis, "markers": markers, "count": count - 1} # count - 1 to exclude background

@vision_node(
    type_id="feat_watershed",
    label="Watershed",
    category='segmentation',
    icon="Target",
    description=(
        "Separates overlapping objects using marker-controlled watershed algorithm.\n\n"
        "Rescue Unseeded Regions: when a Cell Mask is connected, any region of that mask "
        "containing no marker is normally claimed by the background basin and disappears "
        "from the result — a silent loss that hits small objects first, because a seed "
        "threshold set as a percentage of the distance map's global maximum never reaches "
        "them. Turn this on to give every unseeded region its own marker (placed at its "
        "distance-transform peak) before flooding, so nothing is dropped."
    ),
    inputs=[{"id": "image", "color": "image"}, {"id": "markers", "color": "markers"}, {"id": "mask", "color": "mask", "label": "Cell Mask (opt)"}],
    outputs=[{"id": "main", "color": "image"}, {"id": "markers_out", "color": "markers"}, {"id": "count", "color": "scalar"},
             {"id": "boundaries", "color": "mask", "label": "Boundary Lines"}],
    params=[
        {"id": "visualization", "label": "Visualization", "type": "enum", "options": ["Original + Boundaries", "Colorized Regions", "Regions + Boundaries", "Original"], "default": 0},
        {"id": "rescue_unseeded", "label": "Rescue Unseeded Regions", "type": "enum", "options": ["No", "Yes"], "default": 0},
        {"id": "rescue_min_area", "label": "Rescue Min Area (px)", "type": "scalar", "min": 0, "max": 100000, "default": 200},
        {"id": "boundary_color", "label": "Boundary Color", "type": "color", "default": "#FF0000"},
        {"id": "boundary_thickness", "label": "Boundary Thickness", "type": "scalar", "min": 1, "max": 5, "default": 1},
        {"id": "region_alpha", "label": "Region Alpha", "type": "scalar", "min": 0.0, "max": 1.0, "default": 0.5}
    ]
)
class WatershedNode(NodeProcessor):
    # Radius of a rescue marker, in pixels. Big enough to survive the flooding as a
    # distinct basin, small enough not to reach a neighbouring object.
    RESCUE_SEED_RADIUS = 3

    @classmethod
    def _rescue_unseeded(cls, mask, markers, min_area):
        """Give every mask region with no marker its own, placed at its distance peak.

        Without this, cv2.watershed floods such a region from the surrounding
        background basin and the object vanishes from the output.
        """
        binary = (mask > 0).astype(np.uint8)
        n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        if n_labels <= 1:
            return markers

        seeded = set(np.unique(labels[markers > 0]).tolist()) - {0}
        orphans = [i for i in range(1, n_labels)
                   if i not in seeded and stats[i, cv2.CC_STAT_AREA] >= min_area]
        if not orphans:
            return markers

        # One distance transform for the whole mask, then argmax restricted to each
        # orphan — the peak is the point furthest from the object's own border, i.e.
        # the same criterion the seeding branch uses upstream.
        dist = cv2.distanceTransform(binary, cv2.DIST_L2, 5)
        out = markers.copy()
        next_label = int(out.max()) + 1
        for i in orphans:
            x, y, bw, bh = (stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP],
                            stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT])
            sub_lab = labels[y:y + bh, x:x + bw]
            sub_dist = np.where(sub_lab == i, dist[y:y + bh, x:x + bw], 0.0)
            py, px = np.unravel_index(int(np.argmax(sub_dist)), sub_dist.shape)
            cv2.circle(out, (x + int(px), y + int(py)), cls.RESCUE_SEED_RADIUS,
                       int(next_label), -1)
            next_label += 1
        return out

    def process(self, inputs, params):
        img = inputs.get('image')
        markers = inputs.get('markers')
        if img is None or markers is None: return {"main": img, "markers_out": markers, "count": 0}

        if len(img.shape) == 2 or (len(img.shape) == 3 and img.shape[2] == 1):
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        h, w = img.shape[:2]
        if markers.shape[:2] != (h, w):
            markers = cv2.resize(markers.astype(np.float32), (w, h), interpolation=cv2.INTER_NEAREST).astype(np.int32)

        markers_copy = markers.copy().astype(np.int32)
        # Seeds must start at 2 (label 1 = sure background in OpenCV watershed).
        markers_copy[markers_copy > 0] += 1   # seeds: 1→2, 2→3... background stays 0 (unknown)

        mask_in = inputs.get('mask')
        if mask_in is not None:
            m = mask_in if len(mask_in.shape) == 2 else cv2.cvtColor(mask_in, cv2.COLOR_BGR2GRAY)
            if m.shape[:2] != (h, w):
                m = cv2.resize(m, (w, h), interpolation=cv2.INTER_NEAREST)

            if int(params.get('rescue_unseeded', 0)) == 1:
                markers_copy = self._rescue_unseeded(
                    m, markers_copy, int(params.get('rescue_min_area', 200)))

            # Pixels outside cell region = sure background → label 1, won't be flooded
            markers_copy[m == 0] = 1

        res_markers = cv2.watershed(img, markers_copy)

        viz_mode = int(params.get('visualization', 0))
        
        c_hex = str(params.get('boundary_color') or '#FF0000').strip()
        if not c_hex.startswith('#'): c_hex = '#' + c_hex
        try:
            if len(c_hex) == 7:
                r, g, b = int(c_hex[1:3], 16), int(c_hex[3:5], 16), int(c_hex[5:7], 16)
            elif len(c_hex) == 4:
                r, g, b = int(c_hex[1]*2, 16), int(c_hex[2]*2, 16), int(c_hex[3]*2, 16)
            else: raise ValueError()
            b_color = (b, g, r)
        except: b_color = (0, 0, 255)
        b_thick = int(params.get('boundary_thickness', 1))
        alpha = float(params.get('region_alpha', 0.5))

        valid_labels = np.unique(res_markers)
        valid_labels = valid_labels[(valid_labels > 1)]  # >1 excludes background(1) and boundaries(-1)
        count = len(valid_labels)

        def colorize(markers_map):
            n = max(1, count)
            vis = (np.clip(markers_map, 0, None).astype(np.float32) * (255.0 / n)).astype(np.uint8)
            colored = cv2.applyColorMap(vis, cv2.COLORMAP_TURBO)
            colored[markers_map <= 0] = 0
            return colored

        def draw_boundaries(base, thick):
            out = base.copy()
            boundary_mask = (res_markers == -1)
            if thick <= 1:
                out[boundary_mask] = b_color
            else:
                kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (thick, thick))
                dilated = cv2.dilate(boundary_mask.astype(np.uint8), kernel)
                out[dilated > 0] = b_color
            return out

        if viz_mode == 0:  # Original + Boundaries
            out_img = draw_boundaries(img.copy(), b_thick)
        elif viz_mode == 1:  # Colorized Regions
            colored = colorize(res_markers)
            out_img = cv2.addWeighted(img, 1.0 - alpha, colored, alpha, 0)
        elif viz_mode == 2:  # Regions + Boundaries
            colored = colorize(res_markers)
            blended = cv2.addWeighted(img, 1.0 - alpha, colored, alpha, 0)
            out_img = draw_boundaries(blended, b_thick)
        else:  # Original
            out_img = img.copy()

        boundaries = (res_markers == -1).astype(np.uint8) * 255
        boundaries[[0, -1], :] = 0   # cv2.watershed always flags the 1-px image frame as -1
        boundaries[:, [0, -1]] = 0
        return {"main": out_img, "markers_out": res_markers, "count": count, "boundaries": boundaries}

@vision_node(
    type_id="feat_marker_filter",
    label="Marker Filter",
    category='segmentation',
    icon="Filter",
    description="Filters markers (label map) by area, removing regions outside the min/max range.",
    inputs=[{"id": "markers", "color": "markers"}, {"id": "image", "color": "image"}],
    outputs=[{"id": "main", "color": "image"}, {"id": "markers_out", "color": "markers"}, {"id": "count", "color": "scalar"}],
    params=[
        {"id": "min_area", "label": "Min Area", "type": "scalar", "min": 0, "max": 1000000, "default": 0},
        {"id": "max_area", "label": "Max Area", "type": "scalar", "min": 0, "max": 1000000, "default": 100000},
        {"id": "area_unit", "label": "Area Unit", "type": "enum", "options": ["Pixels", "% of image"], "default": 0},
        {"id": "remap_ids", "label": "Remap IDs", "type": "enum", "options": ["No", "Yes"], "default": 1}
    ]
)
class MarkerFilterNode(NodeProcessor):
    def process(self, inputs, params):
        markers = inputs.get('markers')
        img = inputs.get('image')
        if markers is None: return {"main": img, "markers_out": None, "count": 0}

        m = markers.astype(np.int32)
        h, w = m.shape[:2]
        total_pixels = h * w

        min_area = float(params.get('min_area', 0))
        max_area = float(params.get('max_area', 100000))
        area_unit = int(params.get('area_unit', 0))
        remap = int(params.get('remap_ids', 1)) == 1

        if area_unit == 1:  # % of image -> pixels
            min_area = min_area / 100.0 * total_pixels
            max_area = max_area / 100.0 * total_pixels

        valid_labels = np.unique(m)
        valid_labels = valid_labels[valid_labels > 0]

        filtered = np.zeros_like(m)
        kept = 0
        new_id = 1

        for label_id in valid_labels:
            mask = (m == label_id)
            area = float(np.sum(mask))
            if min_area <= area <= max_area:
                if remap:
                    filtered[mask] = new_id
                    new_id += 1
                else:
                    filtered[mask] = label_id
                kept += 1

        n = max(1, kept)
        vis = (np.clip(filtered, 0, None).astype(np.float32) * (255.0 / n)).astype(np.uint8)
        colored = cv2.applyColorMap(vis, cv2.COLORMAP_JET)
        colored[filtered <= 0] = 0

        if img is not None:
            base = img.copy()
            if len(base.shape) == 2 or (len(base.shape) == 3 and base.shape[2] == 1):
                base = cv2.cvtColor(base, cv2.COLOR_GRAY2BGR)
            out_img = cv2.addWeighted(base, 0.5, colored, 0.5, 0)
        else:
            out_img = colored

        return {"main": out_img, "markers_out": filtered, "count": kept}
