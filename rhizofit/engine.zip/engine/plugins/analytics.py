import cv2
import numpy as np
from registry import NodeProcessor, vision_node

@vision_node(
    type_id="sci_plotter",
    label="Plotter",
    category='visualize',
    icon="Activity",
    description="Multi-series real-time graph. Connect any scalar/list inputs dynamically. Resizable.",
    resizable=True,
    dynamic_inputs=True,
    inputs=[],
    outputs=[
        {"id": "main", "color": "image"},
    ],
    params=[
        {"id": "buffer_size", "label": "History Size", "type": "scalar", "min": 10, "max": 1000, "default": 200},
        {"id": "_sec_y_axis", "label": "Y Axis", "type": "section"},
        {"id": "min_y", "label": "Y-Axis Min", "type": "float", "default": 0},
        {"id": "max_y", "label": "Y-Axis Max", "type": "float", "default": 100},
        {"id": "auto_scale", "label": "Auto-Scale", "type": "boolean", "default": True},
        {"id": "_sec_image_size", "label": "Image Size", "type": "section"},
        {"id": "width", "label": "Image Width", "type": "scalar", "min": 100, "max": 1920, "default": 640},
        {"id": "height", "label": "Image Height", "type": "scalar", "min": 100, "max": 1080, "default": 360}
    ]
)
class PlotterNode(NodeProcessor):
    def __init__(self):
        super().__init__()
        self.history = {}
        self.colors = [
            (255, 100, 100), (100, 255, 100), (100, 100, 255),
            (255, 255, 100), (255, 100, 255)
        ]

    def _to_float(self, v):
        if v is None: return None
        if isinstance(v, (int, float, np.number)): return float(v)
        if isinstance(v, (list, np.ndarray)):
            if len(v) == 0: return 0.0
            if isinstance(v[0], dict):
                for key in ['area', 'scalar', 'value', 'confidence']:
                    if key in v[0]: return float(np.mean([item.get(key, 0) for item in v]))
                return float(len(v))
            try:
                return float(np.mean(v))
            except:
                return 0.0
        if isinstance(v, dict):
            for key in ['area', 'scalar', 'value', 'confidence']:
                if key in v: return float(v[key])
            return 1.0
        return 0.0

    def process(self, inputs, params):
        if not hasattr(self, 'history') or self.history is None:
            self.history = {}
        if not hasattr(self, 'colors'):
            self.colors = [
                (255, 100, 100), (100, 255, 100), (100, 100, 255),
                (255, 255, 100), (255, 100, 255)
            ]

        buffer_size = int(params.get('buffer_size', 200))
        min_y = float(params.get('min_y', 0))
        max_y = float(params.get('max_y', 100))
        auto_scale = bool(params.get('auto_scale', True))
        w = int(params.get('width', 640))
        h = int(params.get('height', 360))

        # Dynamic inputs — any key except raw_frame
        series = {k: v for k, v in inputs.items() if k != 'raw_frame' and v is not None}

        # Prune disconnected series
        for k in list(self.history.keys()):
            if k not in series:
                del self.history[k]

        for k, v in series.items():
            val = self._to_float(v)
            if val is not None:
                if k not in self.history:
                    self.history[k] = []
                self.history[k].append(val)
                if len(self.history[k]) > buffer_size:
                    self.history[k] = self.history[k][-buffer_size:]

        img = np.zeros((h, w, 3), dtype=np.uint8) + 20
        for i in range(1, 4):
            cv2.line(img, (0, int(h * i / 4)), (w, int(h * i / 4)), (40, 40, 40), 1)

        if auto_scale:
            all_vals = [v for hist in self.history.values() for v in hist]
            if all_vals:
                min_y = min(all_vals)
                max_y = max(all_vals)
                if max_y == min_y: max_y += 1.0

        y_range = max_y - min_y
        if y_range == 0: y_range = 1.0

        for i, (k, hist) in enumerate(self.history.items()):
            if len(hist) < 2: continue
            color = self.colors[i % len(self.colors)]
            pts = []
            for j, val in enumerate(hist):
                x_px = int(j * w / (buffer_size - 1)) if buffer_size > 1 else 0
                y_px = int(h - ((val - min_y) / y_range * h))
                pts.append([x_px, int(np.clip(y_px, 0, h - 1))])
            cv2.polylines(img, [np.array(pts, np.int32)], False, color, 2, cv2.LINE_AA)
            cv2.putText(img, f"{k}: {hist[-1]:.2f}", (10, 20 + i * 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)

        # Return series scalar values so frontend chart can read nd[portKey]
        result = {'main': img}
        for k, hist in self.history.items():
            if hist:
                result[k] = hist[-1]
        return result

@vision_node(
    type_id="sci_stats",
    label="Statistics",
    category='measure',
    icon="Info",
    description="Calculates key statistical metrics (mean, median, standard deviation) from a list.",
    inputs=[{"id": "data_list", "color": "list"}],
    outputs=[
        {"id": "mean", "color": "scalar"},
        {"id": "median", "color": "scalar"},
        {"id": "std", "color": "scalar"},
        {"id": "min", "color": "scalar"},
        {"id": "max", "color": "scalar"}
    ]
)
class StatsNode(NodeProcessor):
    def process(self, inputs, params):
        data = inputs.get('data_list')
        if not data or not isinstance(data, list):
            return {"mean": 0, "median": 0, "std": 0, "min": 0, "max": 0}
        
        # Flatten if it's a list of dicts (like area)
        nums = []
        for item in data:
            if isinstance(item, (int, float)): nums.append(item)
            elif isinstance(item, dict) and 'area' in item: nums.append(item['area'])
            elif isinstance(item, dict) and 'scalar' in item: nums.append(item['scalar'])
            
        if not nums: return {"mean": 0, "median": 0, "std": 0, "min": 0, "max": 0}
        
        arr = np.array(nums)
        return {
            "mean": float(np.mean(arr)),
            "median": float(np.median(arr)),
            "std": float(np.std(arr)),
            "min": float(np.min(arr)),
            "max": float(np.max(arr))
        }

@vision_node(
    type_id="sci_heatmap",
    label="Density Heatmap",
    category='visualize',
    icon="Wind",
    description="Generates a cumulative heatmap based on provided detection points.",
    inputs=[{"id": "image", "color": "image"}, {"id": "points", "color": "points"}],
    outputs=[{"id": "main", "color": "image"}],
    params=[
        {"id": "res", "label": "Resolution", "type": "scalar", "min": 16, "max": 256, "default": 64},
        {"id": "decay", "label": "Decay (Fade)", "type": "scalar", "min": 0, "max": 0.1, "step": 0.001, "default": 0.01},
        {"id": "intensity", "label": "Intensity", "type": "scalar", "min": 0.1, "max": 5.0, "default": 1.0},
        {"id": "_sec_display", "label": "Display", "type": "section"},
        {"id": "blur", "label": "Blur Radius", "type": "scalar", "min": 0, "max": 21, "step": 2, "default": 5},
        {"id": "colormap", "label": "Colormap", "type": "enum", "options": ["Jet", "Hot", "Magma", "Viridis", "Ocean"], "default": 0},
        {"id": "blend", "label": "Alpha Blend", "type": "scalar", "min": 0, "max": 1.0, "step": 0.1, "default": 0.7},
        {"id": "_sec_control", "label": "Control", "type": "section"},
        {"id": "reset", "label": "Reset Buffer", "type": "trigger", "default": 0}
    ]
)
class HeatmapNode(NodeProcessor):
    def __init__(self):
        self.buffer = None
        self.res = 0

    def process(self, inputs, params):
        img = inputs.get('image')
        points = inputs.get('points')
        
        res = int(params.get('res', 64))
        decay = float(params.get('decay', 0.01))
        intensity = float(params.get('intensity', 1.0))
        reset = int(params.get('reset', 0))

        
        # Init or Reset buffer
        if self.buffer is None or self.res != res or reset == 1:
            self.buffer = np.zeros((res, res), dtype=np.float32)
            self.res = res
            
        # If reset is not active, we update the buffer
        # 1. Decay previous heat
        if decay > 0:
            self.buffer *= (1.0 - decay)
            
        # 2. Add new data (Points or Optical Flow)
        if points is not None:
            # Case A: Optical Flow or Dense Map (numpy array)
            if isinstance(points, np.ndarray):
                try:
                    # If flow has 2 channels (u,v), calculate magnitude
                    if len(points.shape) == 3 and points.shape[2] == 2:
                        mag, _ = cv2.cartToPolar(points[..., 0], points[..., 1])
                        # Resize magnitude map to buffer resolution
                        data_heat = cv2.resize(mag, (res, res))
                        self.buffer += data_heat * (intensity * 0.1) # Scale down flow intensity slightly
                    # If it's a single channel intensity map
                    elif len(points.shape) == 2 or (len(points.shape) == 3 and points.shape[2] == 1):
                        data_heat = cv2.resize(points, (res, res))
                        if data_heat.dtype != np.float32: data_heat = data_heat.astype(np.float32) / 255.0
                        self.buffer += data_heat * intensity
                except Exception as e:
                    print(f"[Heatmap) Flow Error: {e}")
            
            # Case B: List of Points (Detections)
            elif isinstance(points, list) or isinstance(points, dict):
                pts_list = points if isinstance(points, list) else [points]
                for p in pts_list:
                    x, y = 0, 0
                    if isinstance(p, dict):
                        if 'center' in p: 
                            x, y = p['center'].get('x'), p['center'].get('y')
                        elif 'x' in p and 'y' in p:
                            x, y = p.get('x'), p.get('y')
                        elif 'xmin' in p: # box
                            x, y = p['xmin'] + p.get('width', 0.0)/2, p['ymin'] + p.get('height', 0.0)/2
                    
                    if x is None or y is None:
                        continue

                    ix, iy = int(x * res), int(y * res)
                    if 0 <= ix < res and 0 <= iy < res:
                        self.buffer[iy, ix] += intensity

        # 3. Process buffer for display
        # Normalize for visualization
        display_buf = self.buffer.copy()
        max_val = np.max(display_buf)
        if max_val > 0: display_buf /= max_val
        
        # Upscale and colormap
        vis = (display_buf * 255).astype(np.uint8)
        
        # Small blur for smoothness
        blur_r = int(params.get('blur', 5))
        if blur_r > 0:
            if blur_r % 2 == 0: blur_r += 1
            vis = cv2.GaussianBlur(vis, (blur_r, blur_r), 0)
            
        # Apply colormap
        maps = [cv2.COLORMAP_JET, cv2.COLORMAP_HOT, cv2.COLORMAP_MAGMA, cv2.COLORMAP_VIRIDIS, cv2.COLORMAP_OCEAN]
        color_map = maps[int(params.get('colormap', 0))]
        heatmap_img = cv2.applyColorMap(vis, color_map)
        
        if img is None: return {"main": heatmap_img}
        
        # 4. Blend with original
        h, w = img.shape[:2]
        heatmap_resized = cv2.resize(heatmap_img, (w, h))
        blend_alpha = float(params.get('blend', 0.7))
        
        # Ensure background is BGR (handles Grayscale inputs to avoid OpenCV Errors)
        background = img.copy()
        if len(background.shape) == 2 or (len(background.shape) == 3 and background.shape[2] == 1):
            background = cv2.cvtColor(background, cv2.COLOR_GRAY2BGR)
            
        out = cv2.addWeighted(background, 1.0 - blend_alpha, heatmap_resized, blend_alpha, 0)
        return {"main": out}

@vision_node(
    type_id='feat_list_aggregator',
    label='List Aggregator',
    category='data',
    icon='Sigma',
    description="Extracts a key from a list of objects and computes group statistics (Sum, Mean, SD, Count). Useful for summarizing circle/contour lists.",
    inputs=[
        {'id': 'items', 'color': 'list'},
        {'id': 'px_per_unit', 'color': 'scalar', 'label': 'Px/Unit (Calibration)'}
    ],
    outputs=[{'id': 'stats', 'color': 'dict'}],
    params=[
        {'id': 'key', 'label': 'Target Key', 'type': 'string', 'default': 'radius'},
        {'id': 'prefix', 'label': 'Label Prefix', 'type': 'string', 'default': 'Item'},
        {'id': 'is_area', 'label': 'Is Area (squared factor)', 'type': 'boolean', 'default': False},
        {'id': 'unit', 'label': 'Unit Name', 'type': 'string', 'default': 'mm'}
    ]
)
class ListAggregatorNode(NodeProcessor):
    def process(self, inputs, params):
        items = inputs.get('items') or []
        key = params.get('key', 'radius')
        prefix = params.get('prefix', 'Item')
        factor = inputs.get('px_per_unit', 1.0)
        is_area = params.get('is_area', False)
        unit = params.get('unit', 'px')
        
        # If factor is connected but unit is still px, default to mm
        if inputs.get('px_per_unit') is not None and unit == 'px':
            unit = 'mm'

        vals = []
        for item in items:
            if isinstance(item, dict) and key in item:
                vals.append(float(item[key]))
            elif isinstance(item, (int, float)):
                vals.append(float(item))
        
        if not vals:
            return {'stats': {
                f"{prefix} Count": 0,
                f"Avg {key.capitalize()}": 0,
            }}
        
        arr = np.array(vals)
        
        # Calibration
        if factor > 0 and factor != 1.0:
            if is_area:
                arr = arr / (factor ** 2)
            else:
                arr = arr / factor
        else:
            unit = "px"

        return {'stats': {
            f"{prefix} Count": len(vals),
            f"Avg {key.capitalize()} ({unit})": round(float(np.mean(arr)), 4),
            f"Std {key.capitalize()}": round(float(np.std(arr)), 4),
            f"Min {key.capitalize()}": round(float(np.min(arr)), 4),
            f"Max {key.capitalize()}": round(float(np.max(arr)), 4),
            f"Total {key.capitalize()}": round(float(np.sum(arr)), 2)
        }}

@vision_node(
    type_id='sci_analysis_report',
    label='Analysis Report',
    category='measure',
    icon='Clipboard',
    description="Displays a beautiful summary table of all variables. Connect any dictionary (stats, report, etc.).",
    inputs=[{'id': 'data', 'color': 'dict'}],
    outputs=[{'id': 'report', 'color': 'dict'}],
    params=[
        {'id': 'title', 'label': 'Report Title', 'type': 'string', 'default': 'Analysis Report'},
    ]
)
class AnalysisReportNode(NodeProcessor):
    def process(self, inputs, params):
        return {'report': inputs.get('data') or {}}

@vision_node(
    type_id='sci_kmeans_list',
    label='K-Means Classifier',
    category='measure',
    icon='Grid',
    description="Clusters a list of objects (like circles) into K groups based on a numeric property. Adds a 'cluster_id' to each item. Cluster 0 = smallest value, cluster K-1 = largest.",
    inputs=[{'id': 'items', 'color': 'list'}],
    outputs=[
        {'id': 'items', 'color': 'list', 'label': 'Clustered List'},
        {'id': 'stats', 'color': 'dict', 'label': 'Group Stats (count + center)'},
    ],
    params=[
        {'id': 'k',   'label': 'K Clusters',    'type': 'int',    'default': 3, 'min': 2, 'max': 10},
        {'id': 'key', 'label': 'Property Key',   'type': 'string', 'default': 'radius', 'hints': 'item_keys'},
    ]
)
class KMeansListStatsNode(NodeProcessor):
    def process(self, inputs, params):
        items = inputs.get('items') or []
        k_clusters = int(params.get('k', 3))
        key = str(params.get('key', 'radius'))

        # Expose available keys for the inspector chips UI
        available_keys = sorted({
            k for item in items if isinstance(item, dict)
            for k, v in item.items() if isinstance(v, (int, float))
        })

        if len(items) < k_clusters:
            return {'items': items, 'stats': {'error': 'Not enough items'},
                    '_available_keys': available_keys}

        valid_items = [item for item in items if isinstance(item, dict) and key in item]
        if not valid_items:
            return {'items': items, 'stats': {'error': f"No item has key '{key}'"},
                    '_available_keys': available_keys}

        X = np.array([[float(item[key])] for item in valid_items], dtype=np.float32)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.1)
        _, raw_labels, raw_centers = cv2.kmeans(
            X, k_clusters, None, criteria, 10, cv2.KMEANS_PP_CENTERS
        )

        # Remap cluster ids so 0 = smallest centroid, K-1 = largest (stable, predictable)
        center_vals = raw_centers.flatten()
        rank = {orig: rank for rank, orig in enumerate(np.argsort(center_vals))}
        sorted_centers = center_vals[np.argsort(center_vals)]

        tagged = []
        counts = [0] * k_clusters
        for item, raw_label in zip(valid_items, raw_labels.flatten()):
            cluster_id = rank[int(raw_label)]
            counts[cluster_id] += 1
            tagged.append({**item, 'cluster_id': cluster_id})

        stats = {
            f"group_{i}": {'count': counts[i], 'center': round(float(sorted_centers[i]), 4)}
            for i in range(k_clusters)
        }

        return {'items': tagged, 'stats': stats, '_available_keys': available_keys}
